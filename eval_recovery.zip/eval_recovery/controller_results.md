# Controller evaluation

20 trials, 1 conditions, controllers: heuristic, heuristic_recovery.

Mean ± sd over seeds. Success rate (all trials) shows the 95% Wilson interval. Tracking metrics use SUCCESSFUL trials only (n ok shown): a trial that stalls early has a tiny tracking error that says nothing about the controller. Failures are listed below.

## shifted_obstacle

| controller | success | 95% CI | n ok | XTE RMS truth [cm] | XTE max truth [cm] | XTE RMS driving [cm] | est-truth XTE [cm] | effort w^2 driving | effort w^2 total | rotate [s] | time [s] | final lat [cm] | ref adoptions | no-path frames |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| heuristic | 5/10 | 0.24–0.76 | 5 | 15.45 ± 2.14 | 29.94 ± 4.43 | 15.84 ± 2.17 | 10.98 ± 0.55 | 4.26 ± 0.37 | 5.32 ± 0.47 | 1.66 ± 0.18 | 53.24 ± 8.53 | 3.16 ± 0.23 | 9.00 ± 2.55 | 39.00 ± 78.40 |
| heuristic_recovery | 10/10 | 0.72–1.00 | 10 | 15.81 ± 2.02 | 31.05 ± 5.56 | 16.22 ± 2.11 | 11.39 ± 0.72 | 4.33 ± 0.32 | 5.48 ± 0.43 | 1.79 ± 0.35 | 50.90 ± 1.61 | 3.10 ± 0.11 | 9.40 ± 2.01 | 14.30 ± 12.29 |

- heuristic_recovery − heuristic, XTE RMS truth [cm]: median +0.00, heuristic_recovery lower in 1/5 paired seeds, too few pairs for a test
- heuristic_recovery − heuristic, XTE max truth [cm]: median +0.00, heuristic_recovery lower in 1/5 paired seeds, too few pairs for a test
- heuristic_recovery − heuristic, XTE RMS driving [cm]: median +0.00, heuristic_recovery lower in 1/5 paired seeds, too few pairs for a test
- heuristic_recovery − heuristic, effort w^2 driving: median +0.00, heuristic_recovery lower in 1/5 paired seeds, too few pairs for a test
- heuristic_recovery − heuristic, effort w^2 total: median +0.00, heuristic_recovery lower in 1/5 paired seeds, too few pairs for a test
- heuristic_recovery − heuristic, time [s]: median +0.00, heuristic_recovery lower in 1/5 paired seeds, too few pairs for a test

## Failures

- heuristic / shifted_obstacle / seed 0: NO SAFE PATH - STOP (collision=False, final lateral 0.245 m)
- heuristic / shifted_obstacle / seed 2: NO SAFE PATH - STOP (collision=False, final lateral 0.247 m)
- heuristic / shifted_obstacle / seed 4: NO SAFE PATH - STOP (collision=False, final lateral 0.245 m)
- heuristic / shifted_obstacle / seed 6: NO SAFE PATH - STOP (collision=False, final lateral 0.247 m)
- heuristic / shifted_obstacle / seed 7: NO SAFE PATH - STOP (collision=False, final lateral 0.243 m)
