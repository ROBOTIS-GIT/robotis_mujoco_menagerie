# Controller evaluation

100 trials, 2 conditions, controllers: lqr, lqr_r0.25, lqr_r0.5, lqr_r2, lqr_r4.

Mean ± sd over seeds. Success rate (all trials) shows the 95% Wilson interval. Tracking metrics use SUCCESSFUL trials only (n ok shown): a trial that stalls early has a tiny tracking error that says nothing about the controller. Failures are listed below.

## camera_noise_dropout

| controller | success | 95% CI | n ok | XTE RMS truth [cm] | XTE max truth [cm] | XTE RMS driving [cm] | est-truth XTE [cm] | effort w^2 driving | rotate [s] | time [s] | ref adoptions |
|---|---|---|---|---|---|---|---|---|---|---|---|
| lqr | 10/10 | 0.72–1.00 | 10 | 8.35 ± 2.05 | 17.12 ± 2.34 | 8.20 ± 1.82 | 5.93 ± 1.50 | 0.58 ± 0.21 | 10.00 ± 1.59 | 56.64 ± 2.49 | 9.60 ± 1.58 |
| lqr_r0.25 | 10/10 | 0.72–1.00 | 10 | 7.69 ± 1.50 | 16.49 ± 2.16 | 7.57 ± 1.42 | 5.59 ± 1.15 | 1.28 ± 0.23 | 9.31 ± 2.37 | 56.77 ± 3.34 | 10.60 ± 2.84 |
| lqr_r0.5 | 10/10 | 0.72–1.00 | 10 | 8.03 ± 1.54 | 16.83 ± 2.59 | 7.83 ± 1.41 | 6.12 ± 1.04 | 1.08 ± 0.47 | 9.30 ± 2.21 | 56.54 ± 2.39 | 10.10 ± 2.60 |
| lqr_r2 | 5/10 | 0.24–0.76 | 5 | 9.01 ± 2.68 | 15.86 ± 2.89 | 6.65 ± 0.70 | 4.16 ± 0.82 | 0.68 ± 0.24 | 58.66 ± 5.20 | 105.18 ± 5.28 | 9.00 ± 2.24 |
| lqr_r4 | 0/10 | 0.00–0.28 | 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |

## nominal

| controller | success | 95% CI | n ok | XTE RMS truth [cm] | XTE max truth [cm] | XTE RMS driving [cm] | est-truth XTE [cm] | effort w^2 driving | rotate [s] | time [s] | ref adoptions |
|---|---|---|---|---|---|---|---|---|---|---|---|
| lqr | 10/10 | 0.72–1.00 | 10 | 6.29 ± 1.28 | 15.23 ± 1.17 | 6.56 ± 0.99 | 4.31 ± 0.94 | 0.55 ± 0.08 | 11.40 ± 2.32 | 52.57 ± 2.34 | 9.20 ± 0.92 |
| lqr_r0.25 | 10/10 | 0.72–1.00 | 10 | 7.84 ± 1.17 | 16.06 ± 1.03 | 7.90 ± 1.14 | 5.70 ± 0.64 | 1.43 ± 0.41 | 10.78 ± 1.66 | 53.24 ± 2.10 | 9.10 ± 2.69 |
| lqr_r0.5 | 10/10 | 0.72–1.00 | 10 | 7.11 ± 1.36 | 16.26 ± 1.91 | 6.98 ± 1.22 | 4.71 ± 0.80 | 0.94 ± 0.22 | 8.86 ± 0.95 | 50.55 ± 1.33 | 9.60 ± 1.58 |
| lqr_r2 | 7/10 | 0.40–0.89 | 7 | 7.65 ± 2.47 | 16.76 ± 2.26 | 6.80 ± 1.32 | 3.44 ± 0.68 | 0.65 ± 0.08 | 57.51 ± 6.61 | 98.96 ± 6.17 | 10.29 ± 2.81 |
| lqr_r4 | 0/10 | 0.00–0.28 | 0 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |

## Failures

- lqr_r2 / nominal / seed 5: EKF VISUAL DOCK (collision=False, final lateral 0.051 m)
- lqr_r2 / nominal / seed 8: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.449 m)
- lqr_r2 / nominal / seed 9: DOCK: CAMERA REACQUIRE - NO TRANSLATION (collision=False, final lateral 0.129 m)
- lqr_r2 / camera_noise_dropout / seed 0: EKF VISUAL DOCK (collision=False, final lateral 0.074 m)
- lqr_r2 / camera_noise_dropout / seed 2: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.564 m)
- lqr_r2 / camera_noise_dropout / seed 7: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.537 m)
- lqr_r2 / camera_noise_dropout / seed 8: EKF VISUAL DOCK (collision=False, final lateral 0.077 m)
- lqr_r2 / camera_noise_dropout / seed 9: EKF VISUAL DOCK (collision=False, final lateral 0.114 m)
- lqr_r4 / nominal / seed 0: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.579 m)
- lqr_r4 / nominal / seed 1: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.564 m)
- lqr_r4 / nominal / seed 2: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.624 m)
- lqr_r4 / nominal / seed 3: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.707 m)
- lqr_r4 / nominal / seed 4: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.583 m)
- lqr_r4 / nominal / seed 5: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.697 m)
- lqr_r4 / nominal / seed 6: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.639 m)
- lqr_r4 / nominal / seed 7: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.719 m)
- lqr_r4 / nominal / seed 8: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.733 m)
- lqr_r4 / nominal / seed 9: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.575 m)
- lqr_r4 / camera_noise_dropout / seed 0: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.729 m)
- lqr_r4 / camera_noise_dropout / seed 1: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.745 m)
- lqr_r4 / camera_noise_dropout / seed 2: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.708 m)
- lqr_r4 / camera_noise_dropout / seed 3: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.642 m)
- lqr_r4 / camera_noise_dropout / seed 4: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.728 m)
- lqr_r4 / camera_noise_dropout / seed 5: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.730 m)
- lqr_r4 / camera_noise_dropout / seed 6: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.677 m)
- lqr_r4 / camera_noise_dropout / seed 7: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.577 m)
- lqr_r4 / camera_noise_dropout / seed 8: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.641 m)
- lqr_r4 / camera_noise_dropout / seed 9: LIDAR PATH / LQR TRACK (collision=False, final lateral 0.726 m)
